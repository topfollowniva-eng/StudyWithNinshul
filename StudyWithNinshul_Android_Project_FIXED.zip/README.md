# Study With Ninshul — Android project

This is a starter Android Studio project for the requested app.

Included:
- Splash/loading screen
- 2-column dark neon home UI
- 8 requested links (Career Will removed)
- WebView for in-app browsing
- WebView back-history behavior: one page at a time; when there is no history, Home opens
- Local admin login and local link editing

Current local admin password:
NINSHUL123

IMPORTANT:
The local admin panel only changes links on that installed device. It is NOT a secure remote admin system and will NOT update every user's app.

For a real remote admin panel (change links for all users without rebuilding the APK), connect Firebase Authentication + Firestore or Supabase Auth + database. Do not put a shared admin password in the APK.

How to open:
1. Install Android Studio.
2. Open this folder.
3. Let Gradle sync.
4. Run on your Android phone or Build > Generate App Bundle / APK > Generate APK.

The app requires internet permission for websites.


Build fix: Java and Kotlin JVM targets are aligned to Java 17 for Gradle builds.
