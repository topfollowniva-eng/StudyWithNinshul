package com.studywithninshul.app

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding

data class StudyLink(val id: String, val name: String, val url: String)

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var prefs: android.content.SharedPreferences

    private val defaults = listOf(
        StudyLink("pw1", "Physics Wallah 1", "https://pwthor.live/study/batches"),
        StudyLink("pw2", "Physics Wallah 2", "https://m.pwmarco.site/study/batches"),
        StudyLink("rwa1", "RWA 1", "https://learnbyakp.site/rwa/batch"),
        StudyLink("rwa2", "RWA 2", "https://rwa.edustream.indevs.in/"),
        StudyLink("sw1", "Selection Way 1", "https://sw.nextmate.site/"),
        StudyLink("sw2", "Selection Way 2", "https://nexthope.pages.dev/sw/"),
        StudyLink("kgs1", "KGS 1", "https://vidya-verse.ai.studio/khan-gs"),
        StudyLink("kgs2", "KGS 2", "https://kgs-6r2n.vercel.app")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("links", MODE_PRIVATE)
        showSplash()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int = Color.WHITE): TextView =
        TextView(this).apply {
            this.text = text
            setTextSize(size)
            setTextColor(color)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD)
        }

    private fun base(): FrameLayout {
        return FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(2, 9, 20))
        }
    }

    private fun showSplash() {
        root = base()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val logo = ImageView(this).apply {
            setImageResource(com.studywithninshul.app.R.drawable.ic_app_logo)
            layoutParams = LinearLayout.LayoutParams(dp(120), dp(120))
        }
        box.addView(logo)
        box.addView(tv("STUDY WITH", 26f).apply { setPadding(0, dp(20), 0, 0) })
        box.addView(tv("NINSHUL", 34f, Color.rgb(0,191,255)))
        val progress = ProgressBar(this).apply {
            isIndeterminate = true
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { topMargin = dp(30) }
        }
        box.addView(progress)
        box.addView(tv("Loading...", 15f, Color.LTGRAY).apply { setPadding(0, dp(12), 0, 0) })
        root.addView(box, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        android.os.Handler(mainLooper).postDelayed({ showHome() }, 1200)
    }

    private fun getUrl(id: String, fallback: String) = prefs.getString(id, fallback) ?: fallback

    private fun showHome() {
        root = base()
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(14))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_app_logo)
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        }
        header.addView(logo)
        header.addView(tv("STUDY WITH NINSHUL", 20f).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        val admin = Button(this).apply {
            text = "⚙"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { showAdminLogin() }
        }
        header.addView(admin, LinearLayout.LayoutParams(dp(54), dp(54)))
        content.addView(header)

        val grid = GridLayout(this).apply {
            columnCount = 2
            useDefaultMargins = false
        }
        defaults.forEach { item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(18), dp(10), dp(16))
                background = getDrawable(R.drawable.card_bg)
                setOnClickListener { openWeb(item) }
            }
            val icon = ImageView(this).apply {
                setImageResource(R.drawable.ic_app_logo)
                background = getDrawable(R.drawable.icon_bg)
                setPadding(dp(8))
                layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
            }
            card.addView(icon)
            card.addView(tv(item.name, 15f).apply {
                setPadding(0, dp(12), 0, dp(8))
            })
            card.addView(tv("WEB", 12f, Color.rgb(0,191,255)).apply {
                background = getDrawable(R.drawable.web_badge)
                setPadding(dp(10), dp(4), dp(10), dp(4))
            })
            val btn = TextView(this).apply {
                text = "LET'S STUDY"
                setTextColor(Color.WHITE)
                textSize = 13f
                gravity = Gravity.CENTER
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                background = getDrawable(R.drawable.button_bg)
                setPadding(dp(18), dp(10), dp(18), dp(10))
                layoutParams = LinearLayout.LayoutParams(-1, dp(44)).apply {
                    topMargin = dp(12)
                }
                setOnClickListener { openWeb(item) }
            }
            card.addView(btn)
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(225)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            grid.addView(card, params)
        }
        content.addView(grid)
        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openWeb(item: StudyLink) {
        val frame = base()
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        val back = Button(this).apply {
            text = "‹"
            textSize = 30f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                if (web.canGoBack()) web.goBack() else showHome()
            }
        }
        val title = tv(item.name, 15f).apply {
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, dp(56), 1f)
        }
        top.addView(back, LinearLayout.LayoutParams(dp(54), dp(56)))
        top.addView(title)
        val web = WebView(this)
        this.web = web
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        web.settings.setSupportMultipleWindows(false)
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                return if (u.startsWith("http://") || u.startsWith("https://")) {
                    view.loadUrl(u); true
                } else true
            }
            @Deprecated("Deprecated in API 24")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                view.loadUrl(url); return true
            }
        }
        frame.addView(top, FrameLayout.LayoutParams(-1, dp(60), Gravity.TOP))
        frame.addView(web, FrameLayout.LayoutParams(-1, -1).apply { topMargin = dp(60) })
        setContentView(frame)
        web.loadUrl(getUrl(item.id, item.url))
    }

    private lateinit var web: WebView

    private fun showAdminLogin() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24))
        }
        box.addView(tv("ADMIN LOGIN", 24f))
        val password = EditText(this).apply {
            hint = "Password"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        box.addView(password, LinearLayout.LayoutParams(-1, dp(60)))
        val login = Button(this).apply {
            text = "LOGIN"
            setOnClickListener {
                // Local demo password. Replace with Firebase/Supabase auth before publishing.
                if (password.text.toString() == "NINSHUL123") {
                    showAdmin()
                } else Toast.makeText(this@MainActivity, "Wrong password", Toast.LENGTH_SHORT).show()
            }
        }
        box.addView(login)
        val back = Button(this).apply {
            text = "BACK"
            setOnClickListener { showHome() }
        }
        box.addView(back)
        setContentView(base().apply { addView(box, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER)) })
    }

    private fun showAdmin() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20))
        }
        box.addView(tv("ADMIN PANEL", 26f))
        box.addView(tv("Links saved here apply to this installed app.", 13f, Color.LTGRAY).apply {
            setPadding(0, dp(8), 0, dp(18))
        })
        defaults.forEach { item ->
            val name = tv(item.name, 15f).apply { gravity = Gravity.START }
            box.addView(name)
            val edit = EditText(this).apply {
                setText(getUrl(item.id, item.url))
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
                singleLine = true
            }
            box.addView(edit, LinearLayout.LayoutParams(-1, dp(56)))
            val save = Button(this).apply {
                text = "SAVE"
                setOnClickListener {
                    prefs.edit().putString(item.id, edit.text.toString().trim()).apply()
                    Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
                }
            }
            box.addView(save)
        }
        val home = Button(this).apply {
            text = "HOME"
            setOnClickListener { showHome() }
        }
        box.addView(home)
        scroll.addView(box)
        setContentView(scroll)
    }

    override fun onBackPressed() {
        val current = currentFocus
        if (::web.isInitialized && web.parent != null) {
            if (web.canGoBack()) web.goBack() else showHome()
        } else {
            showHome()
        }
    }
}
